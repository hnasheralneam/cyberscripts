#!/bin/sh
if [ "$(id -u)" -ne 0 ]; then
  echo "Rerun as sudo"
  exit 1
fi
echo "=== OS Version ==="
uname -a
cat /etc/os-release
echo
echo "=== Open Ports ==="
sudo ss -tulpn
echo
echo "=== Sudoers ==="
cat /etc/group
echo
echo "=== All users ==="
cat /etc/passwd
cat /etc/shadow
echo
echo "=== Current iptable rules ==="
sudo iptables -L
echo
echo "=== Current running services ==="
systemctl list-units --type=service --state=running
echo
echo "=== Enabled Services ==="
systemctl list-unit-files --type=service | grep enabled
echo
echo "=== SUID bits ==="
sudo find / -perm "/u=s,g=s" -type f 2>/dev/null
echo
echo "=== All ports including rawsockets ==="
sudo lsof -i -P -n
echo "=== Cronjobs ==="
users=$(cut -f1 -d: /etc/passwd)
for u in $users
do
  echo "---[ USER: $u ]---"
  crontab -l -u "$u" 2>/dev/null 
done
sudo crontab -l
cat /etc/cron*/*
